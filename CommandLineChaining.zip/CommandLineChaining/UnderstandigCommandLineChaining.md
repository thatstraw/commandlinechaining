# Understanding Command Line Chaining in Linux

## What is Command Chaining?

Linux  command chaining is a technique of *merging* (or joining if you will) several commands such that  each of them can execute in *sequence* depending on the operator that  separates them and these operators decide how the commands will get  executed. It allows us to run multiple commands in `succession`(one after the other) or  `simultaneously`(at the same time). Chaining commands in Linux allows us to execute multiple commands at the same time and directly through the terminal. It’s like short  one line  shell scripts that can be executed through the terminal directly. 

****

****

***Below are some commonly used chaining operators:***

| Operators                                | Functions                                                    |
| ---------------------------------------- | ------------------------------------------------------------ |
| **&** *(Ampersand)*                      | This send a command, script, or process to the background. In short, it makes a command run in the background |
| **&& **(*Logical AND*)                   | The `&&` operator will only execute the second command if the first command ***SUCCEEDS!*** , in other words if the first command exists with a zero status. |
| **\|\|** (*Logical OR*)                  | It's much more like an else statement in programming. The `||` will only execute the second command if the first command fails. In other words if the first command exits with a none zero status code. |
| **;** (*Semi-colon*)                     | The command following this operator will execute even if the command preceding this operator is not successfully executed. |
| **!** (NOT)                              | The `NOT` is much like the except statement. It will run all the commands except a given condition. It negates an expression within a command. |
| **&&-\|\|** (*AND-OR*)                   | It's a combination of the `AND OR`  operator. It's much like the if-else statement in programming. |
| **\|** (*Pipe*)                          | The output of the command preceding this operator will act as an input of the command succeeding this operator. In other words the output of the another command will be given to the input of the other command. |
| **>,>>, <** (*Input-Output Redirection*) | Redirects the output of a command or a group of commands to a file or stream. |
| **\\** (*Concatenation*)                 | Used to concatenate large commands over several lines in the shell. |
| **()** (**Precedence**)                  | Allows the commands to execute in precedence order.          |
| **{}** (*Combination*)                   | The execution of the command succeeding this operator will depends on the execution of the first command. |



## Working with chaining operators

1.  **Ampersand(&) Operator:** It is used to run a command in the background so that other commands can be executed. It sends a  `process/script/command` to the *background* so that other commands can be  executed in the *foreground*. It increases the effective utilization of  system resources and speeds up the script execution. This is also called as Child process creation or forking in other programming languages. Sometimes, running a shell script directly from the command line interface is inconvenient. Some scripts can take a long time to process, and you may not want to tie up the command line interface waiting. While the script is running, you can’t do anything else in your terminal session. Fortunately, the `ampersand` is a simple solution to that problem. Ampersand sign can be used as follows:

   ![](/home/spectertraww/LinuxCommandLine/Notes/CommandLineChaining/bgcommand.png)

   When you place the ampersand symbol `(&)` after a command, it separates the command from the  shell and runs it as a separate background process on the system. The first thing that displays is the line:

   `[1] 30069`

   The number in the square brackets is the job number assigned by the shell to the background process. The next number is the Process `ID (PID)` the Linux system assigns to the process. Every process running on the Linux system must have a unique `PID`.
   As soon as the system displays these items, a new command line interface prompt appears as show above. You are returned to the shell, and the command you executed runs safely in background mode. At this point, you can enter new commands at the prompt. When the background process finishes, it displays a message on the terminal:

   `[1]  + 30069 done       mousepad` 

   This shows the `job number` and the status of the job `( Done )`, along with the command used
   to start the job, as show below

   ![](/home/spectertraww/LinuxCommandLine/Notes/CommandLineChaining/bgfinishes.png)

   

   ### Pro Tip :bulb:

   Be aware that while the background process is running, some commands/scripts/processes still uses your terminal monitor
   for `STDOUT` and `STDERR `messages, in other words it still uses the terminal for displaying its output and output errors. Here is an example:

   ![](/home/spectertraww/LinuxCommandLine/Notes/CommandLineChaining/gboutput.png)

   Notice that we put the `ping -c3 xtremesec.net` command `1` at the background and a new prompt was given at `2`, but the prompt was populated with the `ping -c3 xtremesec.net`command output as expected. When the `ping -c3 xtremesec.net`command finishes `3`, a clean prompts was now shown. You have  noticed from the example above that the output from the  `ping -c3 xtremesec.net`  `intermixes` with the `shell prompt`.  We can also background as many commands we want as shown:

   ![](/home/spectertraww/LinuxCommandLine/Notes/CommandLineChaining/bgmany.png)

   

   ***Now let's move on to the next operator, but before we start talking about the AND and OR operator i want to talk about the `returning value` or `exit status code/value`***

### Returning Value or Exit Status Code/Value

Programs, commands or processes will return `codes/values` or `exit status codes` if you will, upon finishing execution and the value is stored in an environment variable **`$?` **. So if a program successfully executed or finishes executing without any errors, it will return an `exit status code of zero (0)`, this is a conversion and if a program fails or finish executing with errors, it will return a *non-zero* `exit status code` . So if it's a shell script the status code of the script depends on last script command.  So here is an example showing the status code if the program/command/script exited with errors:

![](/home/spectertraww/LinuxCommandLine/Notes/CommandLineChaining/non-zero-code.png)

Notice that i have tried to ping google.com, since i was offline the ping command will exit with a non-zero status code( in this case it's `2`). 

![](/home/spectertraww/LinuxCommandLine/Notes/CommandLineChaining/zero-code.png)

Notice that the above screen shot clearly shows that if a program,script or process successfully executed without errors the `return value`  will be zero.

***Now we are good to go, let's now talk about the logic AND and Logic OR operators:***

2.  **AND (&&) Operator:** The command succeeding  this operator will only execute if the command preceding it gets  successfully executed. In other words the second command will only execute if the first command successfully executed . So the `&&` operator will check if the exit code of the command preceding it, if it's zero it will execute the command succeeding it else it will not. It is helpful when we want to execute a command  if the first command has executed successfully. Here are a few examples:

   ***Let's say we want to check if a website is online or exists, if it's online or exists download `(index.html)`, here is an example:***

   ![](/home/spectertraww/LinuxCommandLine/Notes/CommandLineChaining/xtremesecup.png)

    Notice that `xtremesec.net` was up so the `ping -c3 xtremesec.net` executed successfully, thus the second command `wget xtremesec` get executed too and we were able to download the `index.html` page of  `xtremesec.net`. So if we try a domain which is down or doesn't exist the `wget xtremesec` command will not get executed as shown below.

   ![](/home/spectertraww/LinuxCommandLine/Notes/CommandLineChaining/xtremesecdown.png)

   

3.  **Logical OR (||) Operator:** The command succeeding this  operator will only execute if the execution of the command preceding it  fails. It is much like an else statement. If the execution status of the first command is non-zero then the second command will get executed. This operator is the opposite of the `logic AND operator` explained above. So the command succeeding this operator will act as a backup of the first command. It's  like we want to make sure if the first command was not successful the second command will back it up.  Here is an example:

   ***We want to check if a directory exists, if it doesn't we  create it!***

   ![](/home/spectertraww/LinuxCommandLine/Notes/CommandLineChaining/logicor.png)

   So you have noticed that the `ls logicOR` command exited with errors `(1)`, thus the second command `mkdir logicOR` was executed and the directory `logicOR` was successfully created `(2)`.  So if the first command had successfully executed the second command wouldn't have  get executed.

   

4.  **AND, OR Operators as an if-else condition:** This command can be used as an if-else statement. It is a combination of `logical AND and logical OR operators`. Here is an example:

   ***We want to check if a domain is online or exists, if it's online or exists download the `index.html` page else print `the domain is down`.

   ![](/home/spectertraww/LinuxCommandLine/Notes/CommandLineChaining/andor1.png)

   Notice that `xtremesec.net` was online, thus the first command `ping xtremesec.net` successfully executed and so as the  second command `wget xtremesec.net`. Since the second command successfully executed, the command succeeding the logic OR `||` will not get executed which is the third command `echo "Xtremesec is Down/Doesn't exists"` . ***Now let's make the first command fail:***

   ![](/home/spectertraww/LinuxCommandLine/Notes/CommandLineChaining/logicorfails.png)

   Since the first command  `ping -c xtremesec.net1` existed with a non-zero status code, the second command `wget xtremesec.net1` will not get executed and the `logic OR` then checks the exit code of the last command, in this case it was *non-zero*. Therefore the third command `echo "Xtremesec is Down/Doesn't exists"` get executed. This is because the `||` operator only executes the command succeeding it if the command preceding it fails.

   ![](/home/spectertraww/LinuxCommandLine/Notes/CommandLineChaining/abcd.png)

   The command in the screen shot above will first check if the directory `‘ABC'` exists or not. If  it does not exist then a new directory is created else `‘ABC’` becomes the current directory. Refer to the image above the directory named `‘ABC’`  does not exist and hence it is created. When the same command is  executed the second time, then the directory already exists and hence  `‘ABC’` becomes the current directory.

   

5. **. Semi-colon(;) Operator:** It is used to run multiple  commands sequentially in a single go. But it is important to note that  the commands chained by (;) operator always executes sequentially. If  two commands are separated by the operator, then the second command will always execute independently of the exit status of the first command.  Unlike the `ampersand operator` or `logical or`, the execution of the second command is  independent of the exit status of the first command. Even if the first  command does not get successfully executed i.e, the exit status is  non-zero, the second command will always execute.

   ![](/home/spectertraww/LinuxCommandLine/Notes/CommandLineChaining/semi-colon.png)

   Notice that the four commands will get executed sequentially. But the execution of  the command preceding `(;)` operator will execute even if the execution  of the first command is not successful.

   

6. **NOT (!) operator:** It is used to negate an expression in command/. We can use it to delete all files except one in a directory. Let's create a folder and name  it `xtremesec` , `cd` into it and then create a couple of files in there as shown below.

   ![](/home/spectertraww/LinuxCommandLine/Notes/CommandLineChaining/createfiles.png)

   ***Now let's delete all the files except for the `file.html`:***

   ![](/home/spectertraww/LinuxCommandLine/Notes/CommandLineChaining/not.png)

   ### Pro Tip :bulb:

   The screen shot above clearly shows that i have changed my `shell` from `zsh` to `bash`  by just executing the `bash` command `(3)` , since the command `rm -r !(file.html)`  `(5)` will not work on `zsh shell`.

   

7.  **Redirection Operators(‘<‘,’>’,’>>’):** This  operator is used to redirect the output of a command or a group of  commands to a stream or file. This operator can be used to redirect  either standard input or standard output or both. Almost all commands  accept input with redirection operators. Here is an example:

   ![](/home/spectertraww/LinuxCommandLine/Notes/CommandLineChaining/redirect1.png)

   The first command `echo "command line chaining is awesome" > xtremesec.txt` creates a file with the name `‘xtremesec.txt’`  (The  redirection operator `> `allows us to give  the output of the `echo` command as an input in the file `xtremesec.txt`, if the file doesn't exists it will be created else if it does all the contents of the file will be replaced  with `command line chaining is awesome`.) while the second `wc -c -l`  command will print the character count and line count  in the xtremesec.txt, in this case we have one line and `33` characters. 

   The  redirection operator `> `allows us to give  the output of the `echo` command as an input in the file `xtremesec.txt`, if the file doesn't exists it will be created else if it does all the contents of the file will be replaced  with `command line chaining is awesome`. Sometimes we don't want the contents of the file to replaced, we just want to append the new text at the end of the text file. This is where the redirection operator `>>` comes in hand. The image below clearly shows that:

   ![](/home/spectertraww/LinuxCommandLine/Notes/CommandLineChaining/append.png)



8.  **Piping (|) Operator:** This operator sends the output of the first command to the input of the second command.

   ![](/home/spectertraww/LinuxCommandLine/Notes/CommandLineChaining/pipe1.png)

   In the above command `wc -l -c` displays the number of lines and characters. `cat xtremesec.txt` displays the contents of the file `xtremesec.txt`.  The `cat xtremesec.txt`  command  will output contents of the file `xtremesec.txt`  is this output is sent to the next command  `wc -l -c` which counts the number of  `lines`  and `characters` in the input. As a result, by using pipe we get the number of lines `2` and characters `51` in the `xtremesec.txt` text file. For more info about `wc` command check out it's `man page or help` 

   ```bash
   # the following command will display the man page of wc
   $ man wc
   
   # the following command will display the wc help
   $ wc --help
   ```

   ### Pro Tip :bulb:

   ***Some commands don't support piping like the ping command as show below:***

   ![](/home/spectertraww/LinuxCommandLine/Notes/CommandLineChaining/ping failed.png)

   But fortunately, there's a way to solve this problem. We can use the `xargs` (***xargs: build and execute command lines from standard input***) command together with the `ping` command as shown below:

   ![](/home/spectertraww/LinuxCommandLine/Notes/CommandLineChaining/xargs.png)

9.  **Concatenation Operator(\\):**  Used to concatenate large  commands over several lines in a shell. It also improves the readability for the users. A large command is split over several lines and hence,  it is used to execute large commands. It is also use to join a filename with spaces between the words as show below:

   ![](/home/spectertraww/LinuxCommandLine/Notes/CommandLineChaining/conca1.png)

    In the image above we have created a file with spaces between the filename words, if we don't put the backlash the words will be treated as separated files to be created. We can also split split a long command over several lines as shown below:

   ![](/home/spectertraww/LinuxCommandLine/Notes/CommandLineChaining/mulit.png)

10. **Precedence:** This command is used to set precedent value so that multiple commands can execute in a given order.

    ```bash
    cmd1 && cmd 2 || cmd3 ( cmd1 && cmd 2 ) || cmd3
    ```

    In the first case, if the first command is successful then the second  will get executed but the third command will not execute. But in the  second case, the third command will get executed as the precedence is  set using the () operator. 

11. **Combination Operator ({}):** The execution of the command succeeding this operator depends on the execution of the first command. The set of commands combined using {} operator executes when the  command preceding it has successfully executed.

    ```bash
    [ -f hello.txt ] && echo "file exists" ; echo "hello"
    [ -f hello.txt ] && { echo "file exists" ; echo "hello"; }
    ```

    In the first case, hello will always get printed. If the file exists  then the command will get executed as it is preceding the &&  operator. If we want to execute both second and third commands only if  the file exists, then we use {} operators to combine the commands.